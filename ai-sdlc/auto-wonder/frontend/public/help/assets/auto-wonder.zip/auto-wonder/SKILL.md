---
name: auto-wonder
description: Use when the user invokes auto-wonder or asks to perform an operation through the AutoWonder platform.
---

# AutoWonder

请使用 AutoWonder 平台的 MCP 进行操作。
